package com.exercise.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="room")
public class Room {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int RO_ID;

private int RO_ROOM_NUMBER;



public int getRO_ID() {
	return RO_ID;
}

public Room(int rO_ID, int rO_ROOM_NUMBER) {
	super();
	RO_ID = rO_ID;
	RO_ROOM_NUMBER = rO_ROOM_NUMBER;
}

public void setRO_ID(int rO_ID) {
	RO_ID = rO_ID;
}



public int getRO_ROOM_NUMBER() {
	return RO_ROOM_NUMBER;
}

public void setRO_ROOM_NUMBER(int rO_ROOM_NUMBER) {
	RO_ROOM_NUMBER = rO_ROOM_NUMBER;
}

public Room() {
	super();
	// TODO Auto-generated constructor stub
}



}
