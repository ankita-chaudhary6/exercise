package com.exercise.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exercise.dao.RoomDAOImpl;
import com.exercise.model.RoomBlocking;

@Service
public class RoomServiceImpl implements RoomService{

	@Autowired
	private RoomDAOImpl roomdao;
	
	@Transactional
	public int getId(int ro_no) {
		int id=roomdao.getId(ro_no);
		return id;
	}

	@Transactional
	public List<RoomBlocking> getDetails(int id) {
		List<RoomBlocking> list=roomdao.getDetails(id);
		return list;
	}
	@Transactional
	public String bookRoom(RoomBlocking obj) {
		return roomdao.bookRoom(obj);
		
	}
	@Transactional
	public void cancelBooking(Date date1, int id) {
		roomdao.cancelBooking(date1,id);
		
	}

}
