package com.exercise.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="ROOM_Blocking")
public class RoomBlocking {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int RB_ID;

	private Date RO_DATE;
	
	private char RB_BOOKED;
	
	 @ManyToOne
	 private Room roomst;

	public int getRB_ID() {
		return RB_ID;
	}

	public void setRB_ID(int rB_ID) {
		RB_ID = rB_ID;
	}

	

	public RoomBlocking(int rB_ID, Date rO_DATE, char rB_BOOKED, Room roomst) {
		super();
		RB_ID = rB_ID;
		RO_DATE = rO_DATE;
		RB_BOOKED = rB_BOOKED;
		this.roomst = roomst;
	}

	public Room getRoomst() {
		return roomst;
	}

	public void setRoomst(Room roomst) {
		this.roomst = roomst;
	}

	public Date getRO_DATE() {
		return RO_DATE;
	}

	public void setRO_DATE(Date rO_DATE) {
		RO_DATE = rO_DATE;
	}

	public char getRB_BOOKED() {
		return RB_BOOKED;
	}

	public void setRB_BOOKED(char rB_BOOKED) {
		RB_BOOKED = rB_BOOKED;
	}

	public RoomBlocking() {
		super();
		// TODO Auto-generated constructor stub
	}


	
}
