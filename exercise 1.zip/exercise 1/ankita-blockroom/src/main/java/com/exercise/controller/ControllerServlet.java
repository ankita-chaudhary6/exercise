package com.exercise.controller;

import java.io.IOException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.exercise.dao.RoomDAOImpl;
import com.exercise.model.Room;
import com.exercise.model.RoomBlocking;
import com.exercise.service.RoomService;


@Controller
public class ControllerServlet {
	@Autowired
	private RoomService rbo;
	static final Logger logger = Logger.getLogger(RoomDAOImpl.class);
	//redirects to the welcome page
	
	@GetMapping("/")
	public String homePage() {
		
		return "welcome";
	}
	
	
//checking the availability of a particular room 
	
	@RequestMapping("/checkAvailability")
	public String checkAvailability(@RequestParam("RO_ROOM_NUMBER") String roomNo, HttpServletRequest request) {
		logger.info("inside controller servlet");
		HttpSession session=request.getSession();
		int room_no = Integer.parseInt(roomNo);
		int id = (int) rbo.getId(room_no);
		List<RoomBlocking> list = rbo.getDetails(id);

		session.setAttribute("listofBooking", list);
		session.setAttribute("bookingDetails", roomNo);
		session.setAttribute("roomId", id);
		session.setAttribute("RO_ROOM_NUMBER", roomNo);
		return "check";
	}
	

	//book the room for a particular date
	
	@GetMapping("/bookNow")
	public String bookNow(HttpServletRequest request) throws ParseException, IOException, ServletException {
		logger.info("inside controller servlet");
		HttpSession session=request.getSession();
		String date = request.getParameter("date");
		session.getAttribute("RO_ROOM_NUMBER");
		SimpleDateFormat adf = new SimpleDateFormat("dd-MMMM-yyyy");
		Date date1 = adf.parse(date);
		int id = Integer.parseInt(request.getParameter("roomId"));
		System.out.println(date + "**********" + id);
		RoomBlocking obj = new RoomBlocking();
		obj.setRB_BOOKED('Y');
		obj.setRO_DATE(date1);
		Room room = new Room();
		room.setRO_ID(id);
		room.setRO_ROOM_NUMBER(Integer.parseInt(request.getParameter("roomNo")));
		obj.setRoomst(room);
		
		String msg=rbo.bookRoom(obj);
		System.out.println(msg);
		
		return "redirect:/";
	}
	
	
	//cancel room booking for a particular date
	
	@GetMapping("/cancelBooking")
	public String cancelBooking(HttpServletRequest request,HttpServletResponse response) throws ParseException
	{
		logger.info("inside controller servlet");
		String date = request.getParameter("date");
		SimpleDateFormat adf = new SimpleDateFormat("dd-MMMM-yyyy");
		Date date1 = adf.parse(date);
		int id = Integer.parseInt(request.getParameter("roomId"));
		rbo.cancelBooking(date1,id);
		return "redirect:/";
	}
}
