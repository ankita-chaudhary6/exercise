package com.exercise.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.exercise.model.Room;
import com.exercise.model.RoomBlocking;

@Repository
public class RoomDAOImpl implements RoomDAO {

	@PersistenceContext
	private EntityManager em;
	static final Logger logger = Logger.getLogger(RoomDAOImpl.class);

	public int getId(int ro_no) {
		logger.info("inside DAO");
		Query query = em.createQuery("from Room where RO_ROOM_NUMBER=" + ro_no);
		Room r = (Room) query.getSingleResult();
		int id = r.getRO_ID();
		logger.info("after query" + id);
		logger.info("room id retrieved");
		return id;
	}

	@SuppressWarnings("unchecked")
	public List<RoomBlocking> getDetails(int id) {
		logger.info("inside DAO");
		List<RoomBlocking> list = new ArrayList<RoomBlocking>();
		Query query = em.createQuery("from RoomBlocking where roomst_ro_id=" + id);
		list = query.getResultList();
		logger.info("list of room booking for a particular room id retrieved");
		return list;
	}

	public String bookRoom(RoomBlocking obj) {
		logger.info("inside DAO");
		em.persist(obj);
		logger.info("room successfully booked");
		return "sucess";
	}

	public void cancelBooking(Date date1, int id) {
		logger.info("inside DAO");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String s = sdf.format(date1);
		Query query = em.createQuery("from RoomBlocking where roomst_ro_id=:id and ro_date=:date");
		query.setParameter("id", id);
		query.setParameter("date", s);
		RoomBlocking r = (RoomBlocking) query.getSingleResult();
		em.remove(r);
		logger.info("room booking successfully canceled");
	}

}
