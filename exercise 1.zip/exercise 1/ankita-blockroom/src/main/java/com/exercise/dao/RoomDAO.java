package com.exercise.dao;

import java.util.Date;
import java.util.List;

import com.exercise.model.RoomBlocking;

public interface RoomDAO {

	int getId(int room_no);

	List<RoomBlocking> getDetails(int id);

	String bookRoom(RoomBlocking obj);

	void cancelBooking(Date date1, int id);

}
